const FORMATION = [
  {
    year: "2024 – 2025",
    title: "1ère année BUT GMP",
    org: "IUT — en alternance",
    desc: "Génie Mécanique et Productique en alternance sur 3 ans. Acquisition de compétences en conception mécanique, production industrielle et gestion de projet technique.",
    tags: ["Conception", "Fabrication", "Alternance", "BUT"],
  },
  {
    year: "Juillet 2024",
    title: "Baccalauréat STI2D — ITEC",
    org: "Innovation Technologique et Éco-Conception",
    desc: "Baccalauréat STI2D spécialité ITEC (Innovation Technologique) obtenu avec Mention Bien. Formation aux sciences de l'ingénieur, à la conception et aux systèmes techniques.",
    tags: ["STI2D", "ITEC", "Mention Bien", "Sciences de l'ingénieur"],
  },
  {
    year: "2023",
    title: "Validation SNU — Phases 1 & 2",
    org: "Service National Universel",
    desc: "Validation des deux phases du SNU entre 2022 et 2023. Développement du sens civique, de la cohésion et de l'engagement.",
    tags: ["SNU", "Civisme", "Engagement"],
  },
  {
    year: "Juin 2021",
    title: "Brevet des Collèges",
    org: "DNB — Mention Très Bien",
    desc: "Diplôme National du Brevet obtenu avec la mention Très Bien.",
    tags: ["DNB", "Mention Très Bien"],
  },
  {
    year: "2019",
    title: "PSC1",
    org: "Premiers Secours Civiques niveau 1",
    desc: "Obtention du PSC1 durant l'année 2018-2019. Formation aux gestes de premiers secours.",
    tags: ["Premiers secours", "PSC1"],
  },
];

const EXPERIENCES = [
  {
    year: "Depuis sept. 2024",
    title: "Alternant — Service Outillage",
    org: "Saint Gobain Sully",
    desc: "Deuxième année d'alternance au sein du service Outillage de l'entreprise Saint Gobain Sully. Conception, suivi et amélioration des outils de production industrielle.",
    tags: ["Outillage", "Production", "Industrie", "Saint Gobain"],
  },
  {
    year: "Février 2023",
    title: "Mission d'intérêt général — SNU Phase 2",
    org: "Base militaire aérienne 123 de Bricy",
    desc: "Mission d'intérêt général d'une semaine au sein de la base militaire aérienne 123 de Bricy dans le cadre du Service National Universel. Découverte du milieu militaire aéronautique.",
    tags: ["SNU", "Militaire", "Aéronautique", "Bricy"],
  },
  {
    year: "Juin 2022",
    title: "Phase 1 SNU — Groupe de cohésion",
    org: "Service National Universel",
    desc: "Groupe de cohésion durant deux semaines. Découverte des métiers publics : pompiers, gendarmes, etc. Travail d'équipe et engagement civique.",
    tags: ["SNU", "Cohésion", "Citoyenneté"],
  },
  {
    year: "Décembre 2021",
    title: "Stage de 3e — Découverte",
    org: "BCI — Gien",
    desc: "Stage de découverte d'une semaine dans l'entreprise BCI à Gien. Première immersion en environnement professionnel industriel.",
    tags: ["Stage", "Découverte", "Industrie"],
  },
  {
    year: "Janvier 2024",
    title: "Permis B",
    org: "Autonomie & mobilité",
    desc: "Obtention du permis de conduire B en janvier 2024.",
    tags: ["Permis B"],
  },
];

export default function Parcours() {
  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem", borderBottom: "1px solid #c8d6e8", paddingBottom: "2rem" }}>
        <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
          03 — Parcours
        </span>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
          Formation & Expériences
        </h1>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4rem" }}>
        {/* Formation */}
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "2rem" }}>
            <span className="font-display" style={{ fontSize: "1.3rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d" }}>Formation</span>
            <div style={{ flex: 1, height: "1px", backgroundColor: "#c8d6e8" }} />
          </div>
          {FORMATION.map((item, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "3px 1fr", gap: "18px", paddingBottom: "1.75rem" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div style={{ width: "3px", height: "10px", backgroundColor: "#1a5fa8", borderRadius: "2px" }} />
                <div style={{ width: "2px", flex: 1, backgroundColor: i < FORMATION.length - 1 ? "#c8d6e8" : "transparent" }} />
              </div>
              <div>
                <span className="font-mono" style={{ fontSize: "0.6rem", color: "#1a5fa8", letterSpacing: "0.1em", display: "block", marginBottom: "5px" }}>
                  {item.year}
                </span>
                <h3 className="font-display" style={{ fontSize: "1.05rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "#18293d", marginBottom: "3px" }}>
                  {item.title}
                </h3>
                <div style={{ fontSize: "0.78rem", color: "#1a5fa8", marginBottom: "7px", fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>
                  {item.org}
                </div>
                <p style={{ fontSize: "0.8rem", color: "#6682a0", lineHeight: 1.7, marginBottom: "10px", fontFamily: "'Inter', sans-serif" }}>
                  {item.desc}
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}>
                  {item.tags.map((t) => (
                    <span key={t} style={{ fontSize: "0.62rem", backgroundColor: "#e4ecf5", border: "1px solid #c8d6e8", color: "#6682a0", padding: "2px 8px", borderRadius: "2px", fontFamily: "'Inter', sans-serif" }}>
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Expériences */}
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "2rem" }}>
            <span className="font-display" style={{ fontSize: "1.3rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d" }}>Expériences</span>
            <div style={{ flex: 1, height: "1px", backgroundColor: "#c8d6e8" }} />
          </div>
          {EXPERIENCES.map((item, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "3px 1fr", gap: "18px", paddingBottom: "1.75rem" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div style={{ width: "3px", height: "10px", backgroundColor: "#2e7dd4", borderRadius: "2px" }} />
                <div style={{ width: "2px", flex: 1, backgroundColor: i < EXPERIENCES.length - 1 ? "#c8d6e8" : "transparent" }} />
              </div>
              <div>
                <span className="font-mono" style={{ fontSize: "0.6rem", color: "#2e7dd4", letterSpacing: "0.1em", display: "block", marginBottom: "5px" }}>
                  {item.year}
                </span>
                <h3 className="font-display" style={{ fontSize: "1.05rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "#18293d", marginBottom: "3px" }}>
                  {item.title}
                </h3>
                <div style={{ fontSize: "0.78rem", color: "#2e7dd4", marginBottom: "7px", fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>
                  {item.org}
                </div>
                <p style={{ fontSize: "0.8rem", color: "#6682a0", lineHeight: 1.7, marginBottom: "10px", fontFamily: "'Inter', sans-serif" }}>
                  {item.desc}
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}>
                  {item.tags.map((t) => (
                    <span key={t} style={{ fontSize: "0.62rem", backgroundColor: "#e4ecf5", border: "1px solid #c8d6e8", color: "#6682a0", padding: "2px 8px", borderRadius: "2px", fontFamily: "'Inter', sans-serif" }}>
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
