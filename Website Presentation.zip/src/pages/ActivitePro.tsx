import { useState } from "react";

const PROJETS = [
  {
    id: 1,
    code: "PRJ-001",
    title: "Service Outillage — Saint Gobain Sully",
    client: "Saint Gobain Sully",
    year: "2024 – présent",
    status: "En cours",
    img: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=700&h=450&fit=crop&auto=format",
    desc: "Deuxième année d'alternance au sein du service Outillage de l'entreprise Saint Gobain Sully. Participation à la conception, au suivi et à l'amélioration des outils utilisés en production industrielle. Travail en équipe pluridisciplinaire dans un environnement industriel exigeant.",
    tags: ["Outillage", "Conception", "Amélioration continue", "Industrie"],
    kpis: [
      { val: "2e", label: "Année alternance" },
      { val: "BUT", label: "GMP en cours" },
      { val: "3 ans", label: "Durée contrat" },
    ],
  },
  {
    id: 2,
    code: "PRJ-002",
    title: "Mission SNU — Base aérienne 123",
    client: "Base militaire aérienne de Bricy",
    year: "Février 2023",
    status: "Validé",
    img: "https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?w=700&h=450&fit=crop&auto=format",
    desc: "Mission d'intérêt général d'une semaine au sein de la base militaire aérienne 123 de Bricy, dans le cadre de la Phase 2 du Service National Universel. Découverte des métiers de l'aéronautique militaire et des missions de défense nationale.",
    tags: ["SNU", "Militaire", "Aéronautique", "Mission civique"],
    kpis: [
      { val: "1 sem.", label: "Durée mission" },
      { val: "BA123", label: "Base Bricy" },
      { val: "Phase 2", label: "SNU validé" },
    ],
  },
  {
    id: 3,
    code: "PRJ-003",
    title: "Stage de découverte — BCI Gien",
    client: "BCI — Gien",
    year: "Décembre 2021",
    status: "Validé",
    img: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=700&h=450&fit=crop&auto=format",
    desc: "Stage de 3e dans l'entreprise BCI à Gien — stage de découverte d'une semaine. Première immersion en milieu professionnel industriel. Observation des processus de production et des métiers techniques.",
    tags: ["Stage", "Industrie", "Découverte", "Gien"],
    kpis: [
      { val: "1 sem.", label: "Durée stage" },
      { val: "3e", label: "Niveau scolaire" },
      { val: "2021", label: "Année" },
    ],
  },
];

export default function ActivitePro() {
  const [selected, setSelected] = useState<number>(1);
  const projet = PROJETS.find((p) => p.id === selected)!;

  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem", borderBottom: "1px solid #c8d6e8", paddingBottom: "2rem" }}>
        <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
          04 — Activité Professionnelle
        </span>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
          Projets & Expériences Pro
        </h1>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "1px", backgroundColor: "#c8d6e8", border: "1px solid #c8d6e8", borderRadius: "6px", overflow: "hidden", minHeight: "500px" }}>
        {/* Sidebar */}
        <div style={{ backgroundColor: "#f0f4f9" }}>
          <div style={{ padding: "10px 14px", borderBottom: "1px solid #c8d6e8", backgroundColor: "#edf1f7" }}>
            <span style={{ fontSize: "0.6rem", color: "#9ab0c8", letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "'Inter', sans-serif" }}>Liste</span>
          </div>
          {PROJETS.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelected(p.id)}
              style={{
                display: "block",
                width: "100%",
                padding: "14px 16px",
                textAlign: "left",
                background: selected === p.id ? "#ffffff" : "none",
                border: "none",
                borderBottom: "1px solid #c8d6e8",
                borderLeft: selected === p.id ? "3px solid #1a5fa8" : "3px solid transparent",
                cursor: "pointer",
                transition: "all 0.15s",
              }}
            >
              <span className="font-mono" style={{ fontSize: "0.55rem", color: "#9ab0c8", letterSpacing: "0.1em", display: "block", marginBottom: "4px" }}>
                {p.code}
              </span>
              <span className="font-display" style={{ fontSize: "0.88rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.03em", color: selected === p.id ? "#18293d" : "#6682a0", display: "block", marginBottom: "6px", lineHeight: 1.3 }}>
                {p.title}
              </span>
              <span style={{ fontSize: "0.6rem", padding: "2px 8px", backgroundColor: p.status === "En cours" ? "#dbeafe" : "#d1fae5", color: p.status === "En cours" ? "#1a5fa8" : "#065f46", borderRadius: "2px", fontFamily: "'Inter', sans-serif" }}>
                {p.status}
              </span>
            </button>
          ))}
        </div>

        {/* Detail */}
        <div style={{ backgroundColor: "#ffffff" }}>
          <div style={{ overflow: "hidden", height: "200px", backgroundColor: "#e4ecf5", position: "relative" }}>
            <img src={projet.img} alt={projet.title} style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.6 }} />
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(255,255,255,0.9) 0%, transparent 60%)" }} />
            <div style={{ position: "absolute", bottom: "1.5rem", left: "1.5rem" }}>
              <h2 className="font-display" style={{ fontSize: "1.6rem", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.04em", color: "#18293d" }}>
                {projet.title}
              </h2>
              <div style={{ fontSize: "0.78rem", color: "#1a5fa8", fontFamily: "'Inter', sans-serif" }}>{projet.client} · {projet.year}</div>
            </div>
          </div>

          <div style={{ padding: "1.5rem" }}>
            <p style={{ fontSize: "0.88rem", color: "#3a5a7a", lineHeight: 1.8, marginBottom: "1.5rem", fontFamily: "'Inter', sans-serif" }}>
              {projet.desc}
            </p>

            {/* KPIs */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "8px", marginBottom: "1.5rem" }}>
              {projet.kpis.map((k) => (
                <div key={k.label} style={{ backgroundColor: "#f0f4f9", border: "1px solid #c8d6e8", padding: "1rem", textAlign: "center", borderRadius: "4px" }}>
                  <div className="font-display" style={{ fontSize: "1.6rem", fontWeight: 700, color: "#1a5fa8" }}>{k.val}</div>
                  <div style={{ fontSize: "0.6rem", color: "#9ab0c8", marginTop: "4px", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>{k.label}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
              {projet.tags.map((t) => (
                <span key={t} style={{ fontSize: "0.68rem", backgroundColor: "#e4ecf5", border: "1px solid #c8d6e8", color: "#6682a0", padding: "3px 10px", borderRadius: "2px", fontFamily: "'Inter', sans-serif" }}>
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
