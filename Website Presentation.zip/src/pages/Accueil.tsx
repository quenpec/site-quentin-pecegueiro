import { Link } from "react-router";
import { useEffect, useState } from "react";

const STATS = [
  { val: "BUT", label: "GMP en alternance" },
  { val: "2", label: "Années SNU" },
  { val: "BAC", label: "STI2D Mention Bien" },
  { val: "Saint Gobain", label: "Entreprise alternance" },
];

const QUICK_LINKS = [
  { to: "/presentation", label: "Présentation", desc: "Qui je suis" },
  { to: "/parcours", label: "Parcours", desc: "Formation & expériences" },
  { to: "/competences", label: "Compétences", desc: "Savoir-faire & savoir-être" },
  { to: "/cv", label: "CV", desc: "Télécharger mon CV" },
];

export default function Accueil() {
  const [typed, setTyped] = useState("");
  const fullText = "Étudiant BUT GMP — Génie Mécanique & Productique";

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      if (i <= fullText.length) {
        setTyped(fullText.slice(0, i));
        i++;
      } else {
        clearInterval(timer);
      }
    }, 45);
    return () => clearInterval(timer);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section
        style={{
          minHeight: "calc(100vh - 59px)",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          position: "relative",
          overflow: "hidden",
          padding: "4rem 2rem",
          backgroundColor: "#f0f4f9",
        }}
      >
        {/* Subtle grid */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage:
              "linear-gradient(#c8d6e820 1px, transparent 1px), linear-gradient(90deg, #c8d6e820 1px, transparent 1px)",
            backgroundSize: "48px 48px",
            pointerEvents: "none",
          }}
        />
        {/* Background photo */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: "url('https://images.unsplash.com/photo-1540962351504-03099e0a754b?w=1600&h=900&fit=crop&auto=format')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            opacity: 0.06,
            pointerEvents: "none",
          }}
        />

        <div style={{ position: "relative", maxWidth: "1400px", margin: "0 auto", width: "100%" }}>
          {/* Label */}
          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "2rem" }}>
            <div style={{ width: "28px", height: "2px", backgroundColor: "#1a5fa8" }} />
            <span
              className="font-mono"
              style={{ fontSize: "0.62rem", color: "#1a5fa8", letterSpacing: "0.16em", textTransform: "uppercase" }}
            >
              Portfolio — 2026
            </span>
          </div>

          {/* Name */}
          <h1
            className="font-display"
            style={{
              fontSize: "clamp(3.5rem, 10vw, 8rem)",
              fontWeight: 800,
              lineHeight: 0.92,
              letterSpacing: "0.02em",
              textTransform: "uppercase",
              color: "#18293d",
              marginBottom: "1.5rem",
            }}
          >
            QUENTIN
            <br />
            <span style={{ color: "#1a5fa8" }}>PECEGUEIRO</span>
          </h1>

          {/* Typed */}
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "clamp(1rem, 2.5vw, 1.4rem)",
              fontWeight: 400,
              color: "#6682a0",
              marginBottom: "3rem",
              minHeight: "2rem",
            }}
          >
            {typed}
            <span className="cursor-blink" style={{ color: "#1a5fa8" }}>|</span>
          </p>

          {/* Stats */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
              gap: "1px",
              backgroundColor: "#c8d6e8",
              border: "1px solid #c8d6e8",
              marginBottom: "3rem",
              maxWidth: "580px",
            }}
          >
            {STATS.map((s) => (
              <div
                key={s.label}
                style={{ backgroundColor: "#ffffff", padding: "1.25rem 1rem", textAlign: "center" }}
              >
                <div
                  className="font-display"
                  style={{ fontSize: "1.6rem", fontWeight: 700, color: "#1a5fa8", lineHeight: 1 }}
                >
                  {s.val}
                </div>
                <div
                  style={{ fontSize: "0.68rem", color: "#9ab0c8", marginTop: "5px", fontFamily: "'Inter', sans-serif" }}
                >
                  {s.label}
                </div>
              </div>
            ))}
          </div>

          {/* CTAs */}
          <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap" }}>
            <Link
              to="/presentation"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                padding: "12px 28px",
                backgroundColor: "#1a5fa8",
                color: "#ffffff",
                textDecoration: "none",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.82rem",
                fontWeight: 600,
                borderRadius: "4px",
                transition: "background 0.2s",
              }}
            >
              Découvrir le profil →
            </Link>
            <Link
              to="/cv"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                padding: "12px 28px",
                border: "1px solid #c8d6e8",
                backgroundColor: "#ffffff",
                color: "#6682a0",
                textDecoration: "none",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.82rem",
                fontWeight: 500,
                borderRadius: "4px",
              }}
            >
              Voir le CV
            </Link>
          </div>
        </div>
      </section>

      {/* Quick links */}
      <section style={{ maxWidth: "1400px", margin: "0 auto", padding: "4rem 2rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "2rem" }}>
          <span style={{ fontSize: "0.72rem", color: "#9ab0c8", letterSpacing: "0.1em", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
            Navigation rapide
          </span>
          <div style={{ flex: 1, height: "1px", backgroundColor: "#c8d6e8" }} />
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: "12px",
          }}
        >
          {QUICK_LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              style={{
                display: "block",
                backgroundColor: "#ffffff",
                border: "1px solid #c8d6e8",
                padding: "1.75rem 1.5rem",
                textDecoration: "none",
                borderRadius: "6px",
                transition: "all 0.2s",
                borderTop: "3px solid #ffffff",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderTopColor = "#1a5fa8";
                (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 16px rgba(26,95,168,0.1)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderTopColor = "#ffffff";
                (e.currentTarget as HTMLElement).style.boxShadow = "none";
              }}
            >
              <div
                className="font-display"
                style={{ fontSize: "1.5rem", fontWeight: 700, color: "#18293d", letterSpacing: "0.04em", textTransform: "uppercase", marginBottom: "6px" }}
              >
                {link.label}
              </div>
              <div style={{ fontSize: "0.75rem", color: "#9ab0c8", fontFamily: "'Inter', sans-serif" }}>
                {link.desc}
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Image strip */}
      <section style={{ padding: "0 2rem 4rem", maxWidth: "1400px", margin: "0 auto" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr 1fr",
            gap: "8px",
            height: "260px",
          }}
        >
          {[
            { src: "https://images.unsplash.com/photo-1559657189-eb21e8c95c1c?w=800&h=400&fit=crop&auto=format", label: "Aéronautique" },
            { src: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=400&h=400&fit=crop&auto=format", label: "Mécanique" },
            { src: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=400&fit=crop&auto=format", label: "Productique" },
          ].map((img) => (
            <div key={img.label} style={{ overflow: "hidden", position: "relative", backgroundColor: "#e4ecf5", borderRadius: "6px" }}>
              <img src={img.src} alt={img.label} style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.75 }} />
              <div style={{ position: "absolute", bottom: "12px", left: "12px" }}>
                <span
                  className="font-mono"
                  style={{ fontSize: "0.6rem", color: "#ffffff", backgroundColor: "rgba(26,95,168,0.85)", padding: "3px 10px", letterSpacing: "0.12em", borderRadius: "2px" }}
                >
                  {img.label}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
