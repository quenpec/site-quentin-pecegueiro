import { useState } from "react";

const VIDEOS = [
  {
    id: 1,
    title: "Présentation — Quentin Pecegueiro",
    duration: "À définir",
    desc: "Vidéo de présentation personnelle : parcours, motivations, alternance chez Saint Gobain et projet professionnel en génie mécanique.",
    thumb: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=640&h=360&fit=crop&auto=format",
    youtubeId: null,
  },
  {
    id: 2,
    title: "Retour d'expérience — SNU Base de Bricy",
    duration: "À définir",
    desc: "Retour sur la mission d'intérêt général effectuée à la base militaire aérienne 123 de Bricy dans le cadre de la Phase 2 du SNU.",
    thumb: "https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?w=640&h=360&fit=crop&auto=format",
    youtubeId: null,
  },
  {
    id: 3,
    title: "Alternance — Service Outillage Saint Gobain",
    duration: "À définir",
    desc: "Présentation de mon alternance au sein du service Outillage de Saint Gobain Sully — missions, apprentissages et projets réalisés.",
    thumb: "https://images.unsplash.com/photo-1559657189-eb21e8c95c1c?w=640&h=360&fit=crop&auto=format",
    youtubeId: null,
  },
];

export default function Video() {
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem", borderBottom: "1px solid #c8d6e8", paddingBottom: "2rem" }}>
        <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
          06 — Vidéo de présentation
        </span>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
          Vidéos
        </h1>
      </div>

      {/* Notice */}
      <div style={{ border: "1px solid #bdd4ef", backgroundColor: "#dbeafe", padding: "1rem 1.5rem", marginBottom: "2.5rem", borderRadius: "6px", display: "flex", alignItems: "flex-start", gap: "10px" }}>
        <span style={{ color: "#1a5fa8", fontSize: "1rem", marginTop: "1px" }}>ℹ</span>
        <div>
          <p style={{ fontSize: "0.82rem", color: "#1e40af", marginBottom: "3px", fontFamily: "'Inter', sans-serif" }}>
            <strong>Ajouter vos vidéos</strong> — Intégrez vos liens YouTube ou Vimeo dans le tableau <code>VIDEOS[]</code> du fichier <code>src/pages/Video.tsx</code>.
          </p>
        </div>
      </div>

      {/* Modal */}
      {selected !== null && (
        <div
          style={{ position: "fixed", inset: 0, backgroundColor: "rgba(15,25,40,0.75)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: "2rem" }}
          onClick={() => setSelected(null)}
        >
          <div style={{ maxWidth: "860px", width: "100%", position: "relative" }} onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setSelected(null)}
              style={{ position: "absolute", top: "-40px", right: 0, background: "#ffffff", border: "1px solid #c8d6e8", color: "#6682a0", padding: "5px 14px", cursor: "pointer", fontFamily: "'Inter', sans-serif", fontSize: "0.75rem", borderRadius: "4px" }}
            >
              Fermer ✕
            </button>
            <div style={{ backgroundColor: "#f0f4f9", border: "1px solid #c8d6e8", aspectRatio: "16/9", display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden", borderRadius: "6px" }}>
              <img src={VIDEOS.find((v) => v.id === selected)?.thumb} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.25 }} />
              <div style={{ position: "relative", textAlign: "center", padding: "2rem" }}>
                <div className="font-display" style={{ fontSize: "1.4rem", fontWeight: 700, textTransform: "uppercase", color: "#18293d", marginBottom: "0.75rem" }}>
                  {VIDEOS.find((v) => v.id === selected)?.title}
                </div>
                <p style={{ fontSize: "0.85rem", color: "#6682a0", maxWidth: "400px", margin: "0 auto 1.5rem", fontFamily: "'Inter', sans-serif" }}>
                  Intégrez ici l'URL de votre vidéo YouTube ou Vimeo.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "12px" }}>
        {VIDEOS.map((v) => (
          <div
            key={v.id}
            style={{ backgroundColor: "#ffffff", border: "1px solid #c8d6e8", borderRadius: "8px", overflow: "hidden", cursor: "pointer", transition: "box-shadow 0.2s" }}
            onClick={() => setSelected(v.id)}
            onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.boxShadow = "0 4px 16px rgba(26,95,168,0.1)")}
            onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.boxShadow = "none")}
          >
            <div style={{ position: "relative", overflow: "hidden", backgroundColor: "#e4ecf5", aspectRatio: "16/9" }}>
              <img src={v.thumb} alt={v.title} style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.7 }} />
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ width: "52px", height: "52px", border: "2px solid #1a5fa8", display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.9)", borderRadius: "50%" }}>
                  <span style={{ color: "#1a5fa8", fontSize: "1.1rem", marginLeft: "3px" }}>▶</span>
                </div>
              </div>
              <div style={{ position: "absolute", bottom: "8px", right: "8px" }}>
                <span style={{ fontSize: "0.6rem", backgroundColor: "rgba(255,255,255,0.9)", color: "#1a5fa8", padding: "2px 8px", borderRadius: "2px", fontFamily: "'Inter', sans-serif" }}>
                  {v.duration}
                </span>
              </div>
            </div>
            <div style={{ padding: "1.1rem" }}>
              <h3 className="font-display" style={{ fontSize: "1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "#18293d", marginBottom: "7px" }}>
                {v.title}
              </h3>
              <p style={{ fontSize: "0.76rem", color: "#6682a0", lineHeight: 1.65, fontFamily: "'Inter', sans-serif" }}>
                {v.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
