import { useState } from "react";

const CATEGORIES = [
  {
    id: "techniques",
    label: "Compétences techniques",
    skills: [
      { name: "CAO / Conception assistée", level: 70, detail: "Initiation en cours, logiciels de dessin industriel" },
      { name: "Dessin technique", level: 75, detail: "Plans, vues, coupes — formation STI2D & BUT" },
      { name: "Fabrication industrielle", level: 65, detail: "Procédés de fabrication, outillage — Saint Gobain" },
      { name: "Métrologie", level: 60, detail: "Mesures et contrôle qualité en production" },
      { name: "Maintenance / Outillage", level: 70, detail: "Service Outillage — Saint Gobain Sully" },
    ],
  },
  {
    id: "informatique",
    label: "Informatique",
    skills: [
      { name: "Suite Office (Word, Excel)", level: 80, detail: "Rédaction, tableaux, présentations" },
      { name: "Logiciels de CAO (initiation)", level: 65, detail: "Formation BUT GMP en cours" },
      { name: "Internet & Recherche", level: 85, detail: "Veille technologique et documentaire" },
      { name: "Présentation / PowerPoint", level: 78, detail: "Exposés, soutenance de projet" },
    ],
  },
  {
    id: "transversales",
    label: "Compétences transversales",
    skills: [
      { name: "Travail en équipe", level: 90, detail: "SNU, alternance, projets scolaires" },
      { name: "Rigueur & Organisation", level: 85, detail: "Respect des délais et des procédures" },
      { name: "Adaptabilité", level: 88, detail: "Milieux variés : entreprise, militaire, scolaire" },
      { name: "Communication", level: 75, detail: "Échanges professionnels, reporting" },
      { name: "Gestion des priorités", level: 78, detail: "Alternance : équilibre cours / entreprise" },
    ],
  },
];

const SAVOIR_ETRES = [
  "Habile / Ingénieux",
  "Sportif",
  "Intelligent / Logique",
  "Calme",
  "Respectueux",
  "Appliqué",
  "Déterminé",
];

const LANGUES = [
  { lang: "Français", level: "Langue maternelle", pct: 100 },
  { lang: "Anglais", level: "Niveau scolaire — en progression", pct: 55 },
  { lang: "Espagnol", level: "Niveau scolaire", pct: 45 },
];

export default function Competences() {
  const [activeTab, setActiveTab] = useState("techniques");
  const cat = CATEGORIES.find((c) => c.id === activeTab)!;

  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem", borderBottom: "1px solid #c8d6e8", paddingBottom: "2rem" }}>
        <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
          07 — Compétences
        </span>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
          Savoir-faire & Savoir-être
        </h1>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #c8d6e8", marginBottom: "2.5rem", flexWrap: "wrap" }}>
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveTab(c.id)}
            style={{
              padding: "10px 18px",
              background: "none",
              border: "none",
              borderBottom: activeTab === c.id ? "2px solid #1a5fa8" : "2px solid transparent",
              color: activeTab === c.id ? "#1a5fa8" : "#9ab0c8",
              fontFamily: "'Inter', sans-serif",
              fontSize: "0.8rem",
              fontWeight: activeTab === c.id ? 600 : 400,
              cursor: "pointer",
              transition: "all 0.15s",
              marginBottom: "-1px",
            }}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Skills */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem 4rem", marginBottom: "3.5rem" }}>
        {cat.skills.map((skill) => (
          <div key={skill.name}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px", alignItems: "baseline" }}>
              <div>
                <span className="font-display" style={{ fontSize: "1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "#18293d" }}>
                  {skill.name}
                </span>
                <span style={{ fontSize: "0.7rem", color: "#9ab0c8", marginLeft: "8px", fontFamily: "'Inter', sans-serif" }}>{skill.detail}</span>
              </div>
              <span style={{ fontSize: "0.68rem", color: "#1a5fa8", fontFamily: "'Inter', sans-serif", fontWeight: 600 }}>
                {skill.level}%
              </span>
            </div>
            <div style={{ height: "5px", backgroundColor: "#e4ecf5", borderRadius: "3px", overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${skill.level}%`, background: "linear-gradient(90deg, #1a5fa8, #2e7dd4)", borderRadius: "3px", transition: "width 0.5s ease" }} />
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "3rem" }}>
        {/* Langues */}
        <div style={{ borderTop: "1px solid #c8d6e8", paddingTop: "2.5rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "1.75rem" }}>
            <span className="font-display" style={{ fontSize: "1.3rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d" }}>Langues</span>
            <div style={{ flex: 1, height: "1px", backgroundColor: "#c8d6e8" }} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {LANGUES.map((l) => (
              <div key={l.lang}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                  <span className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700, textTransform: "uppercase", color: "#18293d" }}>{l.lang}</span>
                  <span style={{ fontSize: "0.75rem", color: "#9ab0c8", fontFamily: "'Inter', sans-serif" }}>{l.level}</span>
                </div>
                <div style={{ height: "4px", backgroundColor: "#e4ecf5", borderRadius: "2px" }}>
                  <div style={{ height: "100%", width: `${l.pct}%`, backgroundColor: "#1a5fa8", borderRadius: "2px" }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Savoir-êtres */}
        <div style={{ borderTop: "1px solid #c8d6e8", paddingTop: "2.5rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "1.75rem" }}>
            <span className="font-display" style={{ fontSize: "1.3rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d" }}>Savoir-être</span>
            <div style={{ flex: 1, height: "1px", backgroundColor: "#c8d6e8" }} />
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
            {SAVOIR_ETRES.map((s) => (
              <span
                key={s}
                style={{
                  padding: "8px 16px",
                  backgroundColor: "#ffffff",
                  border: "1px solid #c8d6e8",
                  borderRadius: "20px",
                  fontSize: "0.82rem",
                  color: "#3a5a7a",
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500,
                }}
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
