const INFOS = [
  { label: "Nom", val: "Quentin Pecegueiro" },
  { label: "Localisation", val: "Gien (45500), France" },
  { label: "Téléphone", val: "07 68 77 43 25" },
  { label: "Email", val: "quenpec4580@gmail.com" },
  { label: "Permis", val: "Permis B (janvier 2024)" },
  { label: "Disponibilité", val: "En alternance — Saint Gobain Sully" },
];

const VALEURS = [
  { icon: "⚙", title: "Habile & Ingénieux", desc: "Capacité à trouver des solutions techniques concrètes, à bricoler et concevoir avec les moyens disponibles." },
  { icon: "🧠", title: "Intelligent & Logique", desc: "Raisonnement structuré et analytique, issu d'une formation scientifique solide (Bac STI2D, BUT GMP)." },
  { icon: "🤝", title: "Calme & Respectueux", desc: "Attitude posée et bienveillante en équipe, avec un sens aigu de l'écoute et du travail collaboratif." },
  { icon: "🎯", title: "Appliqué & Déterminé", desc: "Engagement total dans chaque mission — de l'alternance chez Saint Gobain au SNU en base militaire." },
];

export default function Presentation() {
  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem", borderBottom: "1px solid #c8d6e8", paddingBottom: "2rem" }}>
        <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
          02 — Présentation
        </span>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
          Qui suis-je ?
        </h1>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: "3.5rem", alignItems: "start" }}>
        {/* Left */}
        <div>
          <div style={{ position: "relative", marginBottom: "2rem" }}>
            <div style={{ border: "1px solid #c8d6e8", overflow: "hidden", backgroundColor: "#e4ecf5", borderRadius: "6px" }}>
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=600&fit=crop&auto=format"
                alt="Portrait de Quentin Pecegueiro"
                style={{ width: "100%", aspectRatio: "4/5", objectFit: "cover", display: "block", opacity: 0.9 }}
              />
            </div>
            <div style={{ position: "absolute", bottom: "-6px", right: "-6px", width: "40px", height: "40px", border: "3px solid #1a5fa8", borderRadius: "2px", pointerEvents: "none" }} />
          </div>

          {/* Info table */}
          <div style={{ border: "1px solid #c8d6e8", backgroundColor: "#ffffff", borderRadius: "6px", overflow: "hidden" }}>
            <div style={{ padding: "10px 16px", borderBottom: "1px solid #c8d6e8", backgroundColor: "#edf1f7" }}>
              <span style={{ fontSize: "0.6rem", color: "#9ab0c8", letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "'Inter', sans-serif" }}>Informations</span>
            </div>
            {INFOS.map((info, i) => (
              <div
                key={info.label}
                style={{
                  display: "grid",
                  gridTemplateColumns: "100px 1fr",
                  borderBottom: i < INFOS.length - 1 ? "1px solid #edf1f7" : "none",
                  padding: "10px 16px",
                  gap: "8px",
                }}
              >
                <span style={{ fontSize: "0.68rem", color: "#9ab0c8", letterSpacing: "0.06em", textTransform: "uppercase", fontFamily: "'Inter', sans-serif", alignSelf: "center" }}>
                  {info.label}
                </span>
                <span style={{ fontSize: "0.82rem", color: "#18293d", fontFamily: "'Inter', sans-serif" }}>
                  {info.val}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right */}
        <div>
          <h2 className="font-display" style={{ fontSize: "1.8rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "#1a5fa8", marginBottom: "1.25rem" }}>
            Mon profil
          </h2>
          <p style={{ fontSize: "0.95rem", color: "#3a5a7a", lineHeight: 1.85, marginBottom: "1.25rem", fontFamily: "'Inter', sans-serif" }}>
            Après une formation en STI2D spécialité ITEC (Innovation Technologique et Éco-Conception), j'ai obtenu mon baccalauréat avec mention Bien en juillet 2024. Je suis actuellement en alternance pour 3 ans afin de préparer un BUT Génie Mécanique et Productique (GMP).
          </p>
          <p style={{ fontSize: "0.95rem", color: "#3a5a7a", lineHeight: 1.85, marginBottom: "1.25rem", fontFamily: "'Inter', sans-serif" }}>
            Mon alternance se déroule au sein du service Outillage de l'entreprise <strong style={{ color: "#18293d" }}>Saint Gobain Sully</strong>, où je développe des compétences concrètes en conception, fabrication et gestion d'outils industriels.
          </p>
          <p style={{ fontSize: "0.95rem", color: "#3a5a7a", lineHeight: 1.85, marginBottom: "3rem", fontFamily: "'Inter', sans-serif" }}>
            Engagé dans le <strong style={{ color: "#18293d" }}>Service National Universel (SNU)</strong>, j'ai validé les deux phases entre 2022 et 2023, notamment une mission en base militaire aérienne. Cette expérience a renforcé ma rigueur, mon sens de l'effort collectif et mon intérêt pour le milieu aéronautique et de défense.
          </p>

          {/* Values */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
            {VALEURS.map((v) => (
              <div key={v.title} style={{ backgroundColor: "#ffffff", border: "1px solid #c8d6e8", padding: "1.25rem", borderRadius: "6px", borderTop: "3px solid #1a5fa8" }}>
                <div style={{ fontSize: "1.1rem", marginBottom: "8px" }}>{v.icon}</div>
                <div className="font-display" style={{ fontSize: "0.95rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "#18293d", marginBottom: "6px" }}>
                  {v.title}
                </div>
                <div style={{ fontSize: "0.75rem", color: "#6682a0", lineHeight: 1.65, fontFamily: "'Inter', sans-serif" }}>
                  {v.desc}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
