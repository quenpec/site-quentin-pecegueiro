import cvPdf from "../imports/About_Me.pdf";

export default function CV() {
  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div
        style={{
          marginBottom: "2.5rem",
          borderBottom: "1px solid #c8d6e8",
          paddingBottom: "2rem",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-end",
          flexWrap: "wrap",
          gap: "1.5rem",
        }}
      >
        <div>
          <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
            08 — Curriculum Vitæ
          </span>
          <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
            Mon CV
          </h1>
        </div>
        <a
          href={cvPdf}
          download="CV_Quentin_Pecegueiro.pdf"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "10px",
            padding: "13px 28px",
            backgroundColor: "#1a5fa8",
            color: "#ffffff",
            textDecoration: "none",
            fontFamily: "'Inter', sans-serif",
            fontSize: "0.85rem",
            fontWeight: 600,
            borderRadius: "6px",
            boxShadow: "0 2px 12px rgba(26,95,168,0.25)",
            transition: "background 0.2s, box-shadow 0.2s",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.backgroundColor = "#154e8f";
            (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(26,95,168,0.35)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.backgroundColor = "#1a5fa8";
            (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 12px rgba(26,95,168,0.25)";
          }}
        >
          ↓ Télécharger le CV (PDF)
        </a>
      </div>

      {/* Aperçu + infos */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: "2rem", alignItems: "start" }}>

        {/* CV reconstruit */}
        <div style={{ backgroundColor: "#ffffff", border: "1px solid #c8d6e8", borderRadius: "8px", overflow: "hidden" }}>

          {/* En-tête CV */}
          <div style={{ backgroundColor: "#1a5fa8", padding: "2.5rem 2.5rem 2rem", display: "grid", gridTemplateColumns: "1fr auto", gap: "1.5rem", alignItems: "start" }}>
            <div>
              <h2 className="font-display" style={{ fontSize: "2.8rem", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#ffffff", lineHeight: 1, marginBottom: "6px" }}>
                Quentin
              </h2>
              <h2 className="font-display" style={{ fontSize: "2.8rem", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#a8c8f0", lineHeight: 1, marginBottom: "1.25rem" }}>
                Pecegueiro
              </h2>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                {[
                  { icon: "☎", val: "07 68 77 43 25" },
                  { icon: "✉", val: "quenpec4580@gmail.com" },
                  { icon: "⌖", val: "93 chemin de Gien le Vieux, 45500 Gien" },
                  { icon: "🪪", val: "Permis B — janvier 2024" },
                ].map((c) => (
                  <div key={c.val} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ color: "#a8c8f0", fontSize: "0.8rem" }}>{c.icon}</span>
                    <span style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.85)", fontFamily: "'Inter', sans-serif" }}>{c.val}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ border: "3px solid rgba(255,255,255,0.3)", overflow: "hidden", width: "90px", height: "110px", flexShrink: 0, borderRadius: "4px" }}>
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=240&fit=crop&auto=format"
                alt="Photo de Quentin Pecegueiro"
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
          </div>

          {/* Présentation */}
          <div style={{ padding: "1.5rem 2.5rem", borderBottom: "1px solid #edf1f7", backgroundColor: "#f8fafd" }}>
            <h3 className="font-display" style={{ fontSize: "1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "#1a5fa8", marginBottom: "8px" }}>
              Présentation
            </h3>
            <p style={{ fontSize: "0.85rem", color: "#3a5a7a", lineHeight: 1.75, fontFamily: "'Inter', sans-serif" }}>
              Après une formation STI2D, je suis actuellement en alternance pour 3 ans pour préparer un BUT Génie Mécanique et Productique au sein du service Outillage de Saint Gobain Sully.
            </p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "0" }}>
            {/* Colonne gauche */}
            <div style={{ borderRight: "1px solid #edf1f7", padding: "1.5rem 2rem" }}>

              {/* Langues */}
              <div style={{ marginBottom: "1.5rem", paddingBottom: "1.5rem", borderBottom: "1px solid #edf1f7" }}>
                <h3 className="font-display" style={{ fontSize: "0.85rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", color: "#ffffff", backgroundColor: "#1a5fa8", padding: "5px 10px", marginBottom: "12px", display: "inline-block" }}>
                  Langues
                </h3>
                {["Anglais", "Espagnol"].map((l) => (
                  <div key={l} style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                    <span style={{ color: "#1a5fa8", fontSize: "0.6rem" }}>•</span>
                    <span style={{ fontSize: "0.8rem", color: "#18293d", fontFamily: "'Inter', sans-serif" }}>{l}</span>
                  </div>
                ))}
              </div>

              {/* Savoir-être */}
              <div>
                <h3 className="font-display" style={{ fontSize: "0.85rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", color: "#ffffff", backgroundColor: "#1a5fa8", padding: "5px 10px", marginBottom: "12px", display: "inline-block" }}>
                  Savoir-être
                </h3>
                {["Habile / Ingénieux", "Sportif", "Intelligent / Logique", "Calme", "Respectueux", "Appliqué", "Déterminé"].map((s) => (
                  <div key={s} style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                    <span style={{ color: "#1a5fa8", fontSize: "0.6rem" }}>•</span>
                    <span style={{ fontSize: "0.78rem", color: "#18293d", fontFamily: "'Inter', sans-serif" }}>{s}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Colonne droite */}
            <div style={{ padding: "1.5rem 2rem" }}>
              {/* Expériences */}
              <div style={{ marginBottom: "1.5rem", paddingBottom: "1.5rem", borderBottom: "1px solid #edf1f7" }}>
                <h3 className="font-display" style={{ fontSize: "0.85rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", color: "#ffffff", backgroundColor: "#1a5fa8", padding: "5px 10px", marginBottom: "14px", display: "inline-block" }}>
                  Expérience
                </h3>
                {[
                  { date: "Depuis sept. 2024", title: "Alternance — Service Outillage", org: "Saint Gobain Sully", desc: "2ème année d'alternance au sein du service Outillage." },
                  { date: "Février 2023", title: "Mission SNU Phase 2", org: "Base aérienne 123 de Bricy", desc: "Mission d'intérêt général — 1 semaine en base militaire aérienne." },
                  { date: "Juin 2022", title: "SNU Phase 1", org: "Groupe de cohésion", desc: "2 semaines de découverte des métiers publics (pompiers, gendarmes...)." },
                  { date: "Décembre 2021", title: "Stage de 3e", org: "BCI — Gien", desc: "Stage de découverte d'une semaine." },
                ].map((exp, i) => (
                  <div key={i} style={{ marginBottom: "12px" }}>
                    <div className="font-display" style={{ fontSize: "0.85rem", fontWeight: 700, color: "#18293d" }}>{exp.date}</div>
                    <div style={{ fontSize: "0.8rem", color: "#1a5fa8", fontWeight: 600, fontFamily: "'Inter', sans-serif" }}>{exp.title}</div>
                    <div style={{ fontSize: "0.72rem", color: "#6682a0", fontFamily: "'Inter', sans-serif" }}>{exp.org}</div>
                    <div style={{ fontSize: "0.74rem", color: "#3a5a7a", fontFamily: "'Inter', sans-serif", marginTop: "2px" }}>{exp.desc}</div>
                  </div>
                ))}
              </div>

              {/* Formations */}
              <div>
                <h3 className="font-display" style={{ fontSize: "0.85rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", color: "#ffffff", backgroundColor: "#1a5fa8", padding: "5px 10px", marginBottom: "14px", display: "inline-block" }}>
                  Formations et Diplômes
                </h3>
                {[
                  { date: "2024–2025", title: "1ère année BUT GMP", detail: "En alternance" },
                  { date: "Juillet 2024", title: "Baccalauréat STI2D — ITEC", detail: "Mention Bien" },
                  { date: "2023", title: "Validation SNU Phases 1 & 2", detail: "2022–2023" },
                  { date: "Juin 2021", title: "Brevet des collèges", detail: "Mention Très Bien" },
                  { date: "2019", title: "PSC1", detail: "Premiers Secours Civiques — 2018-2019" },
                ].map((f, i) => (
                  <div key={i} style={{ marginBottom: "10px" }}>
                    <div className="font-display" style={{ fontSize: "0.85rem", fontWeight: 700, color: "#18293d" }}>{f.date}</div>
                    <div style={{ fontSize: "0.8rem", color: "#3a5a7a", fontFamily: "'Inter', sans-serif" }}>{f.title}</div>
                    {f.detail && <div style={{ fontSize: "0.7rem", color: "#9ab0c8", fontFamily: "'Inter', sans-serif" }}>{f.detail}</div>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar droite */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px", position: "sticky", top: "80px" }}>

          {/* Télécharger */}
          <div style={{ backgroundColor: "#ffffff", border: "1px solid #c8d6e8", borderRadius: "8px", padding: "1.5rem", borderTop: "3px solid #1a5fa8" }}>
            <h3 className="font-display" style={{ fontSize: "1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d", marginBottom: "10px" }}>
              Télécharger
            </h3>
            <p style={{ fontSize: "0.78rem", color: "#6682a0", fontFamily: "'Inter', sans-serif", marginBottom: "14px", lineHeight: 1.6 }}>
              Téléchargez mon CV au format PDF pour le consulter ou le transmettre.
            </p>
            <a
              href={cvPdf}
              download="CV_Quentin_Pecegueiro.pdf"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "11px 20px",
                backgroundColor: "#1a5fa8",
                color: "#ffffff",
                textDecoration: "none",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.82rem",
                fontWeight: 600,
                borderRadius: "5px",
                width: "100%",
                boxSizing: "border-box",
              }}
            >
              ↓ Télécharger le PDF
            </a>
          </div>

          {/* Ouvrir dans le navigateur */}
          <div style={{ backgroundColor: "#ffffff", border: "1px solid #c8d6e8", borderRadius: "8px", padding: "1.5rem" }}>
            <h3 className="font-display" style={{ fontSize: "1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d", marginBottom: "10px" }}>
              Ouvrir le PDF
            </h3>
            <a
              href={cvPdf}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "11px 20px",
                border: "1px solid #c8d6e8",
                backgroundColor: "#f0f4f9",
                color: "#1a5fa8",
                textDecoration: "none",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.82rem",
                fontWeight: 500,
                borderRadius: "5px",
                width: "100%",
                boxSizing: "border-box",
              }}
            >
              ↗ Voir dans le navigateur
            </a>
          </div>

          {/* Contact rapide */}
          <div style={{ backgroundColor: "#edf1f7", border: "1px solid #c8d6e8", borderRadius: "8px", padding: "1.5rem" }}>
            <h3 className="font-display" style={{ fontSize: "1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "#18293d", marginBottom: "12px" }}>
              Contact
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {[
                { icon: "✉", val: "quenpec4580@gmail.com" },
                { icon: "☎", val: "07 68 77 43 25" },
                { icon: "⌖", val: "Gien (45500)" },
              ].map((c) => (
                <div key={c.val} style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                  <span style={{ color: "#1a5fa8", fontSize: "0.75rem", marginTop: "1px" }}>{c.icon}</span>
                  <span style={{ fontSize: "0.75rem", color: "#3a5a7a", fontFamily: "'Inter', sans-serif" }}>{c.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
