const ACTIVITES = [
  {
    cat: "Sport & Activité physique",
    icon: "🏃",
    img: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=600&h=400&fit=crop&auto=format",
    alt: "Sport et activité physique",
    desc: "Pratique régulière du sport, reflet d'une valeur personnelle forte. La discipline sportive m'apprend la persévérance, la gestion de l'effort et le dépassement de soi — des qualités directement transférables en ingénierie.",
    details: ["Activité physique régulière", "Goût du dépassement de soi", "Discipline et régularité", "Esprit d'équipe"],
  },
  {
    cat: "Mécanique & Bricolage",
    icon: "🔧",
    img: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=600&h=400&fit=crop&auto=format",
    alt: "Mécanique et bricolage",
    desc: "Passion pour la mécanique et la compréhension des systèmes techniques. J'aime démonter, comprendre et remonter des mécanismes — une curiosité naturelle qui a guidé mon orientation vers le génie mécanique.",
    details: ["Réparation et entretien mécanique", "Compréhension des systèmes", "Curiosité technique", "Résolution de problèmes concrets"],
  },
  {
    cat: "Aéronautique & Défense",
    icon: "✈",
    img: "https://images.unsplash.com/photo-1540962351504-03099e0a754b?w=600&h=400&fit=crop&auto=format",
    alt: "Aéronautique militaire",
    desc: "Intérêt marqué pour le secteur aéronautique et de défense, renforcé par la mission SNU à la base aérienne 123 de Bricy. Attrait pour les systèmes aérospatiaux, les structures d'aéronefs et les technologies de pointe du secteur.",
    details: ["Mission à la BA123 de Bricy (SNU)", "Intérêt pour les aéronefs militaires", "Suivi de l'actualité aérospatiale", "Orientation BUT GMP vers aéro"],
  },
  {
    cat: "Civisme & Engagement",
    icon: "🎖",
    img: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=600&h=400&fit=crop&auto=format",
    alt: "Engagement civique et collectif",
    desc: "Participation au Service National Universel (Phases 1 et 2, 2022–2023) et obtention du PSC1 dès 2018–2019. Ces engagements témoignent d'un sens de la responsabilité citoyenne et d'un goût pour le travail collectif.",
    details: ["SNU Phase 1 & 2 validées", "PSC1 — Premiers Secours Civiques", "Découverte des métiers publics", "Esprit de groupe et engagement"],
  },
];

export default function ActivitePerso() {
  return (
    <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "3rem 2rem 5rem", backgroundColor: "#f0f4f9" }}>
      {/* Header */}
      <div style={{ marginBottom: "3rem", borderBottom: "1px solid #c8d6e8", paddingBottom: "2rem" }}>
        <span style={{ fontSize: "0.65rem", color: "#1a5fa8", letterSpacing: "0.16em", display: "block", marginBottom: "0.75rem", fontFamily: "'Inter', sans-serif", textTransform: "uppercase" }}>
          05 — Activité Personnelle
        </span>
        <h1 className="font-display" style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.03em", color: "#18293d", lineHeight: 1 }}>
          Passions & Loisirs
        </h1>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "12px" }}>
        {ACTIVITES.map((act) => (
          <div
            key={act.cat}
            style={{ backgroundColor: "#ffffff", border: "1px solid #c8d6e8", borderRadius: "8px", overflow: "hidden", display: "flex", flexDirection: "column", transition: "box-shadow 0.2s, transform 0.2s" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow = "0 6px 24px rgba(26,95,168,0.1)";
              (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow = "none";
              (e.currentTarget as HTMLElement).style.transform = "none";
            }}
          >
            <div style={{ overflow: "hidden", height: "160px", backgroundColor: "#e4ecf5", position: "relative" }}>
              <img src={act.img} alt={act.alt} style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.7 }} />
              <div style={{ position: "absolute", top: "12px", left: "12px", fontSize: "1.6rem" }}>{act.icon}</div>
            </div>

            <div style={{ padding: "1.25rem", flex: 1 }}>
              <h3 className="font-display" style={{ fontSize: "1.1rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "#18293d", marginBottom: "8px" }}>
                {act.cat}
              </h3>
              <p style={{ fontSize: "0.8rem", color: "#6682a0", lineHeight: 1.7, marginBottom: "1rem", fontFamily: "'Inter', sans-serif" }}>
                {act.desc}
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
                {act.details.map((d) => (
                  <div key={d} style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                    <span style={{ color: "#1a5fa8", fontSize: "0.55rem", marginTop: "5px", flexShrink: 0 }}>▶</span>
                    <span style={{ fontSize: "0.76rem", color: "#6682a0", fontFamily: "'Inter', sans-serif" }}>{d}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
