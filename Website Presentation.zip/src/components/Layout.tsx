import { NavLink, Outlet, useLocation } from "react-router";
import { useState, useEffect } from "react";

const NAV = [
  { to: "/", label: "Accueil", code: "01" },
  { to: "/presentation", label: "Présentation", code: "02" },
  { to: "/parcours", label: "Parcours", code: "03" },
  { to: "/activite-pro", label: "Activité Pro", code: "04" },
  { to: "/activite-perso", label: "Activité Perso", code: "05" },
  { to: "/video", label: "Vidéo", code: "06" },
  { to: "/competences", label: "Compétences", code: "07" },
  { to: "/cv", label: "CV", code: "08" },
];

export default function Layout() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#f0f4f9", color: "#18293d" }}>
      {/* Top accent line */}
      <div style={{ height: "3px", background: "linear-gradient(90deg, #1a5fa8 0%, #2e7dd4 60%, #a8c8f0 100%)" }} />

      {/* Nav */}
      <nav
        style={{
          position: "fixed",
          top: "3px",
          left: 0,
          right: 0,
          zIndex: 100,
          backgroundColor: scrolled ? "rgba(255,255,255,0.97)" : "#ffffff",
          borderBottom: "1px solid #c8d6e8",
          backdropFilter: scrolled ? "blur(12px)" : "none",
          boxShadow: scrolled ? "0 1px 16px rgba(26,95,168,0.07)" : "none",
          transition: "all 0.3s ease",
        }}
      >
        <div
          style={{
            maxWidth: "1400px",
            margin: "0 auto",
            padding: "0 2rem",
            display: "flex",
            alignItems: "center",
            height: "56px",
          }}
        >
          {/* Logo */}
          <div style={{ marginRight: "2rem", flexShrink: 0 }}>
            <span
              className="font-display"
              style={{ fontSize: "1.3rem", fontWeight: 800, letterSpacing: "0.06em", color: "#18293d" }}
            >
              QUENTIN<span style={{ color: "#1a5fa8" }}> P.</span>
            </span>
          </div>

          {/* Desktop links */}
          <div
            className="hidden-mobile"
            style={{ display: "flex", alignItems: "center", flex: 1, overflowX: "auto" }}
          >
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                style={({ isActive }) => ({
                  display: "flex",
                  alignItems: "center",
                  gap: "5px",
                  padding: "0 13px",
                  height: "56px",
                  textDecoration: "none",
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "0.78rem",
                  fontWeight: isActive ? 600 : 400,
                  letterSpacing: "0.04em",
                  color: isActive ? "#1a5fa8" : "#6682a0",
                  borderBottom: isActive ? "2px solid #1a5fa8" : "2px solid transparent",
                  transition: "all 0.2s ease",
                  whiteSpace: "nowrap",
                })}
              >
                {item.label}
              </NavLink>
            ))}
          </div>

          {/* Mobile hamburger */}
          <div style={{ marginLeft: "auto" }} className="show-mobile">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Menu"
              style={{
                background: "none",
                border: "1px solid #c8d6e8",
                color: "#18293d",
                padding: "6px 14px",
                cursor: "pointer",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.72rem",
                letterSpacing: "0.06em",
                borderRadius: "4px",
              }}
            >
              {menuOpen ? "✕" : "Menu"}
            </button>
          </div>
        </div>

        {/* Mobile dropdown */}
        {menuOpen && (
          <div
            style={{
              borderTop: "1px solid #c8d6e8",
              backgroundColor: "#ffffff",
              padding: "0.5rem 2rem 1rem",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                style={({ isActive }) => ({
                  display: "block",
                  padding: "11px 0",
                  textDecoration: "none",
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "0.85rem",
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? "#1a5fa8" : "#6682a0",
                  borderBottom: "1px solid #edf1f7",
                })}
              >
                {item.label}
              </NavLink>
            ))}
          </div>
        )}
      </nav>

      {/* Page content */}
      <main style={{ paddingTop: "59px" }}>
        <Outlet />
      </main>

      {/* Footer */}
      <footer
        style={{
          borderTop: "1px solid #c8d6e8",
          backgroundColor: "#ffffff",
          padding: "1.5rem 2rem",
          marginTop: "4rem",
        }}
      >
        <div
          style={{
            maxWidth: "1400px",
            margin: "0 auto",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "1rem",
          }}
        >
          <span
            className="font-mono"
            style={{ fontSize: "0.62rem", color: "#9ab0c8", letterSpacing: "0.08em" }}
          >
            QUENTIN PECEGUEIRO — BUT GMP — GÉNIE MÉCANIQUE & PRODUCTIQUE
          </span>
          <span
            className="font-mono"
            style={{ fontSize: "0.62rem", color: "#c8d6e8", letterSpacing: "0.08em" }}
          >
            © 2026
          </span>
        </div>
      </footer>

      <style>{`
        @media (max-width: 900px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: block !important; }
        }
        @media (min-width: 901px) {
          .show-mobile { display: none !important; }
          .hidden-mobile { display: flex !important; }
        }
      `}</style>
    </div>
  );
}
