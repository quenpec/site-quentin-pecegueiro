import { createBrowserRouter } from "react-router";
import Layout from "./components/Layout";
import Accueil from "./pages/Accueil";
import Presentation from "./pages/Presentation";
import Parcours from "./pages/Parcours";
import ActivitePro from "./pages/ActivitePro";
import ActivitePerso from "./pages/ActivitePerso";
import Video from "./pages/Video";
import Competences from "./pages/Competences";
import CV from "./pages/CV";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Accueil },
      { path: "presentation", Component: Presentation },
      { path: "parcours", Component: Parcours },
      { path: "activite-pro", Component: ActivitePro },
      { path: "activite-perso", Component: ActivitePerso },
      { path: "video", Component: Video },
      { path: "competences", Component: Competences },
      { path: "cv", Component: CV },
    ],
  },
]);
